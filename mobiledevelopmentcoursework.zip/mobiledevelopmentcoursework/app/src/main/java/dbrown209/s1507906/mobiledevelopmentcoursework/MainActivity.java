
/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 ___Derek Brown______________
// Student ID           ______________S1507906___
// Programme of Study   ___________Computing______
//

// Update the package name to include your Student Identifier
package dbrown209.s1507906.mobiledevelopmentcoursework;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;
import android.widget.Toolbar;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;

import dbrown209.s1507906.mobiledevelopmentcoursework.R;

public class MainActivity extends AppCompatActivity
{
    private TextView rawDataDisplay;
    private Button startButton;
    private String result;
    private String url1="";
    private String urlSource="http://quakes.bgs.ac.uk/feeds/MhSeismology.xml";


    InputStream urlSourceInputStream = new ByteArrayInputStream(urlSource.getBytes(StandardCharsets.UTF_8));
    private ListView quakeListView;
    LinkedList<Earthquake> allQuakes;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set up the raw links to the graphical components
        //rawDataDisplay = (TextView)findViewById(R.id.rawDataDisplay);
        //startButton = (Button)findViewById(R.id.startButton);
       //startButton.setOnClickListener(this);
        startProgress();
        // More Code goes here
    }

    public void onClick(View aview)
    {
        startProgress();
    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        Log.e("HERE","HERE");

        new Thread(new Task(urlSource)).start();
    } //

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    private class Task implements Runnable
    {
        private String url;

        public Task(String aurl)
        {
            url = aurl;

        }


        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in;
            String inputLine = "";


            Log.e("MyTag","in run");

            try
            {
                Log.e("MyTag","in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                Log.e("MyTag","in try");

                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                Log.e("MyTag","in try3");

                // Throw away the first 2 header lines before parsing
                //
                //
                //
                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;
                    Log.e("MyTag",inputLine);
                    url1 = url1 + inputLine;

                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception");
            }

            //
            // Now that you have the xml data you can parse it
            //
            pullparse parser = new pullparse();
            allQuakes = parser.parse(url1);
            // Now update the TextView to display raw XML data
            // Probably not the best way to update TextView
            // but we are just getting started !

            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");

                    //ArrayAdapter<Earthquake> adapt = new ArrayAdapter<>(getApplicationContext(), a)

                    EarthquakeAdapter adapter = new EarthquakeAdapter(getApplicationContext(), allQuakes);

                    final ListView quakeListView = (ListView) findViewById(R.id.quakeList);


/////onclick to produce second page
                    quakeListView.setAdapter(adapter);

           quakeListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
               @Override
               public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
               //Toast.makeText(MainActivity.this,"Additonal Information: " + allQuakes.get(i), Toast.LENGTH_SHORT).show();
                   Intent page = new Intent(MainActivity.this,SecondScreen.class);
                   page.putExtra("quake", quakeListView.getItemAtPosition(i).toString());
                   startActivity(page);





               }
           });



                }
            });
        }

    }

}
