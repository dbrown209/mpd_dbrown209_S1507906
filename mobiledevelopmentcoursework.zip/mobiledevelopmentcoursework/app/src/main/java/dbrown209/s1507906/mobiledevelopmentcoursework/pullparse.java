 package dbrown209.s1507906.mobiledevelopmentcoursework;

///


 /*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 ___Derek Brown______________
// Student ID           ______________S1507906___
// Programme of Study   ___________Computing______
//



import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedList;

public class pullparse {

       LinkedList<Earthquake> allQuakes;
       private Earthquake earthquake;
       private String text;

       public pullparse (){
           allQuakes = new LinkedList<>();
           Log.e("pullparser cons","item element");


       }

       //get all earthquakes

       public LinkedList<Earthquake> parse(String pDataToParse) {

             Boolean quakeStart = false;
             XmlPullParserFactory factory;
             XmlPullParser pparser;


             try {

                 factory = XmlPullParserFactory.newInstance();
                 factory.setNamespaceAware(true);

                 pparser = factory.newPullParser();
                 pparser.setInput(new StringReader(pDataToParse));

                 int eventType = pparser.getEventType();



                 while (eventType != XmlPullParser.END_DOCUMENT) {
                     String tagname = pparser.getName();

                     switch (eventType) {
                         case XmlPullParser.START_TAG:
                             if (tagname.equalsIgnoreCase( "item")){
                             earthquake = new Earthquake();
                                 Log.e("HERE","item element");
                                 Log.e("HERE","item element");
                                 Log.e("HERE","item element");
                                 Log.e("HERE","item element");
                                 Log.e("HERE","item element");

                             }
                         break;
                         case XmlPullParser.TEXT:

                             text = pparser.getText();
                             break;


                         case XmlPullParser.END_TAG:
                             if (tagname.equalsIgnoreCase("image")){
                                 quakeStart = true;
                             }
                             else if (tagname.equalsIgnoreCase("item")){
                                 allQuakes.add(earthquake);
                             }
                             else if (tagname.equalsIgnoreCase( "title") &&quakeStart == true){
                                 earthquake.setTitle(text);
                             }else if (tagname.equalsIgnoreCase("description") &&quakeStart == true){

                             //parseDesrip

                               String temp = text;
                               String[] array = temp.split(";");

                             //location
                               earthquake.setLocation(array[1].substring(11));


                              //latlong
                              earthquake.setLatLong(array[2].substring(11));

                             //depth
                              earthquake.setDepth(array[3].substring(7));

                             //Magnitude
                             earthquake.setMagnitude((array[4].substring(11)));


                             earthquake.setDescription(text);
                         }else if (tagname.equalsIgnoreCase("pubdate")){
                             earthquake.setPubDate(text);
                         }else if (tagname.equalsIgnoreCase("category")){
                             earthquake.setCategory(text);
                         }
                             else if (tagname.equalsIgnoreCase("lat")){
                                 earthquake.setLatLong(text);
                             }
                             else if (tagname.equalsIgnoreCase("long")){
                                 earthquake.setLatLong(earthquake.getLatLong() + " " + text);
                             }



                         default:
                             break;
                     }
                     eventType = pparser.next();

                 }

             }catch (XmlPullParserException ae1){
                 Log.e("XmlPullParserException","item element");


             }catch (IOException ae1){
                 Log.e("IOException","item element");

             }

             return allQuakes;
       }
}
