package dbrown209.s1507906.mobiledevelopmentcoursework;

/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 ___Derek Brown______________
// Student ID           ______________S1507906___
// Programme of Study   ___________Computing______
//


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.LinkedList;

import static java.security.AccessController.getContext;

public class EarthquakeAdapter  extends BaseAdapter {

       private Context eq;
       private LinkedList<Earthquake> AlleQuakes;

       ///////Constructor creation/////////

    public EarthquakeAdapter(Context eContext, LinkedList<Earthquake> eAllQuakes) {

        this.eq = eContext;
        this.AlleQuakes = eAllQuakes;

    }


    @Override
    public int getCount() {
        return AlleQuakes.size();

    }


    @Override
    public Object getItem(int position) { return AlleQuakes.get(position); }


    @Override
    public long getItemId(int position) { return position; }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
//        View view = View.inflate(eContext, R.layout.item_view,  null);


        if(convertView == null)
        {
            convertView = LayoutInflater.from(eq).inflate(R.layout.item_view,  parent, false);

        }
      //  TextView tvMagnitude = (TextView) convertView.findViewById(R.id.textmagnitude);
      //  TextView tvDepth = (TextView) convertView.findViewById(R.id.textdepth);
     //  TextView tvLatLong = (TextView) convertView.findViewById(R.id.textlatlong);

        TextView tvLocation = (TextView) convertView.findViewById(R.id.textlocation);
        TextView tv0Date = (TextView) convertView.findViewById(R.id.tv0Date);


        //setting text view

        tv0Date.setText(AlleQuakes.get(position).getPubDate());
        tvLocation.setText(AlleQuakes.get(position).getLocation());
     //   tvLatLong.setText(eAllQuakes.get(position).getLatLong());

       // tvDepth.setText(eAllQuakes.get(position).getDepth());
    //    tvMagnitude.setText(eAllQuakes.get(position).getMagnitude());

        return convertView;



    }



}
