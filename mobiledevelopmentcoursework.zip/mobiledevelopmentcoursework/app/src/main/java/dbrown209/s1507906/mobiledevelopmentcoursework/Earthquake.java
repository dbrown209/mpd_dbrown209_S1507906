package dbrown209.s1507906.mobiledevelopmentcoursework;

/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 ___Derek Brown______________
// Student ID           ______________S1507906___
// Programme of Study   ___________Computing______
//


public class Earthquake {

private String title;
private String description;
private String pubDate;
private String category;
private String Depth;
private String location;
private String LatLong;
private String Magnitude;


//default value constructor

    public Earthquake() {title = "UK Eartquake Alert";}

    //toString() method

    public  String toString ()
    {
////Dispalying information for second screen
       String instanceInfo;
       instanceInfo = "Place of Origin:" + "\n" + getLocation() +
               "\n" + "\n" + "Magnitude:" +  getMagnitude()+
               "\n" +"\n"+ "Latitude/Longitude: "+ getLatLong() +
               "\n" +"\n" + "Depth:" +getDepth() +
               "\n" +"\n"  +"published Date" + "\n" +getPubDate();


       return instanceInfo;

    }


     //getters setters

    public String getTitle()  {return title;}

    public void setTitle(String pTitle)  {this.title = pTitle;}


    public String getDescription()  {return description;}

    public void setDescription(String pDescription)  {this.description = pDescription;}


    public String getPubDate()  {return pubDate;}

    public void setPubDate(String pPubDate)  {this.pubDate = pPubDate;}


    public String getCategory()  {return category;}

    public void setCategory(String pCategory)  {this.category = pCategory;}


    public String getDepth()  {return Depth;}

    public void setDepth(String pDepth)  {this.Depth = pDepth;}


    public String getLocation()  {return location;}

    public void setLocation(String pLocation)  {this.location = pLocation;}


    public String getLatLong()  {return LatLong;}

    public void setLatLong(String pLatLong)  {this.LatLong = pLatLong;}


    public String getMagnitude()  {return Magnitude;}

    public void setMagnitude(String pMagnitude)  {this.Magnitude = pMagnitude;}











}
