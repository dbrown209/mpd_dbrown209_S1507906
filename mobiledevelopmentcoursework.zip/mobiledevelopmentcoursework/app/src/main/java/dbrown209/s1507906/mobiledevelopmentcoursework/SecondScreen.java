package dbrown209.s1507906.mobiledevelopmentcoursework;

/*  Starter project for Mobile Platform Development in Semester B Session 2018/2019
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 ___Derek Brown______________
// Student ID           ______________S1507906___
// Programme of Study   ___________Computing______
//


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);

///Second View for information screen
        TextView text = (TextView) findViewById(R.id.textLocation);
        Bundle view = getIntent().getExtras();
        text.setText(view.getString("quake"));





















    }
}
